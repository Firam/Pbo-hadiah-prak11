/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hadiahp11;

/**
 *
 * @author Felicia Mulia
 */
import java.awt.*;
public class Hadiahp11 extends Panel{
    

    /**
     * @param args the command line arguments
     */
    Hadiahp11() {
        setBackground(Color.GRAY); //konstanta dalam color
    }
    public void paint(Graphics g) {
        Font f = new Font("Helvetica", Font.BOLD,20);
        FontMetrics fm = getFontMetrics(f);
        g.setFont(f);
        // kotak atas
        g.setColor(Color.white);
        g.fillRect(50,8,380,80);
        g.drawRect(50,8,380,80);
        // kotak bawah
        g.setColor(Color.green);
        g.fillRect(50,80,480,110);
        g.drawRect(50,80,480,110);
        //roda 1
        g.setColor(Color.yellow);
        g.drawOval(100, 150, 100, 100);
        g.fillOval(100,150,100,100);
        //roda 2
        g.setColor(Color.yellow);
        g.drawOval(330,150,100,100);
        g.fillOval(330,150,100,100);        
             
        
        String s = "Ini mobil saya dan nama saya adalah Fira Imoet";
        int xpos = (this.size().width - fm.stringWidth(s)) /2;
        int ypos = (this.size().height) /2;
        g.setColor(Color.black);
        g.setFont(f);
        g.drawString(s, xpos, ypos);
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        Frame f = new Frame("Testing Graphics Panel");
        Hadiahp11 gp = new Hadiahp11();
        f.add(gp);
        f.setSize(600,600);
        f.setVisible(true);
    }
    
}
